#!/sbin/sh
# Extract libraries from the user's installed, unchanged Google APK.
# No Google files are part of this script or its support ZIP.
set -eu
root=$1
scratch=$2
expected=$3
names=$4
apk=$root/priv-app/PrebuiltGmsCorePix/PrebuiltGmsCorePix.apk
dest=$root/priv-app/PrebuiltGmsCorePix/lib/arm
fail() { echo "$*" >&2; exit 1; }
case "$root" in
    /system) test_mode=0 ;;
    /tmp/roth-gms-test-*/system) test_mode=1 ;;
    *) fail 'Unsupported installation path' ;;
esac
test -f "$apk" && test ! -L "$apk" || fail 'Expected Google services APK not found'
actual=$(sha256sum "$apk"); actual=${actual%% *}
test "$actual" = "$expected" || fail 'Different Google services APK; no changes made'
test ! -L "$root/priv-app/PrebuiltGmsCorePix" || fail 'Refusing symlinked app directory'
test ! -L "$root/priv-app/PrebuiltGmsCorePix/lib" || fail 'Refusing symlinked native directory'
test ! -L "$dest" || fail 'Refusing symlinked native directory'
test ! -e "$scratch" || fail 'Scratch directory must be new'
mkdir -m 700 "$scratch"
needed=0
count=0
while IFS= read -r name; do
    case "$name" in ''|*[!a-zA-Z0-9_.-]*) fail 'Invalid library list' ;; esac
    test ! -L "$dest/$name" || fail 'Refusing symlinked native library; no changes made'
    unzip -p "$apk" "lib/armeabi-v7a/$name" > "$scratch/$name" || fail 'Required library missing from APK'
    magic=$(od -An -tx1 -N6 "$scratch/$name" | tr -d ' \n')
    machine=$(od -An -tx1 -j18 -N2 "$scratch/$name" | tr -d ' \n')
    test "$magic" = 7f454c460101 && test "$machine" = 2800 || fail 'Library is not little-endian ARM ELF32'
    if test -e "$dest/$name"; then
        cmp -s "$scratch/$name" "$dest/$name" || fail 'Existing library differs; no changes made'
    else
        size=$(wc -c < "$scratch/$name")
        needed=$((needed + (size + 4095) / 4096 * 4))
    fi
    count=$((count + 1))
done < "$names"
test "$count" -eq 19 || fail 'Expected nineteen native libraries'
space_report=$(df -Pk "$root") || fail 'Cannot check system free space'
{
    IFS= read -r space_header || fail 'Cannot check system free space'
    IFS=' ' read -r space_device space_blocks space_used available space_percent space_mount space_extra || fail 'Cannot check system free space'
    test -n "$space_mount" && test -z "$space_extra" || fail 'Unexpected free-space report'
    if IFS= read -r space_extra_line; then
        fail 'Unexpected extra free-space report'
    fi
} <<EOF
$space_report
EOF
case "$available" in ''|*[!0-9]*) fail 'Cannot check system free space' ;; esac
test "$available" -ge "$((needed + 4096))" || fail 'Not enough system space; no libraries installed'
if test "$test_mode" -eq 0; then
    command -v chcon >/dev/null 2>&1 || fail 'SELinux labelling tool unavailable; no libraries installed'
fi
mkdir -p "$dest"
while IFS= read -r name; do
    if test ! -e "$dest/$name"; then
        cp "$scratch/$name" "$dest/$name"
    fi
    chmod 644 "$dest/$name"
    if test "$test_mode" -eq 0; then
        chown 0:0 "$dest/$name"
        chcon u:object_r:system_file:s0 "$dest/$name"
    fi
    cmp -s "$scratch/$name" "$dest/$name" || fail 'Installed library verification failed'
done < "$names"
chmod 755 "$dest" "$root/priv-app/PrebuiltGmsCorePix/lib"
if test "$test_mode" -eq 0; then
    chown 0:0 "$dest" "$root/priv-app/PrebuiltGmsCorePix/lib"
    chcon u:object_r:system_file:s0 "$dest" "$root/priv-app/PrebuiltGmsCorePix/lib"
fi
after=$(sha256sum "$apk"); after=${after%% *}
test "$after" = "$expected" || fail 'APK identity changed unexpectedly'
echo 'Verified nineteen native libraries. Google APK unchanged.'
